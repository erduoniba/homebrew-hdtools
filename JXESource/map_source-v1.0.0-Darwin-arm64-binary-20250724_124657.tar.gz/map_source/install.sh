#!/bin/bash
#
# JXTools 二进制安装脚本
# 安装预编译的二进制文件
#

set -e

BINARY_NAME="map_source"
INSTALL_PREFIX="${INSTALL_PREFIX:-${HOME}/.local}"
INSTALL_DIR="$INSTALL_PREFIX/bin"

# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $*"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }

show_help() {
    cat << EOF
JXTools 二进制安装脚本

用法: $0 [选项]

选项:
  --prefix PATH       指定安装前缀 (默认: ~/.local)
  --system            系统级安装 (安装到 /usr/local)
  --uninstall         卸载
  -h, --help          显示帮助

特点:
  - 安装预编译的二进制文件
  - 无需 bash 或其他运行时依赖
  - 适用于内网环境分发

示例:
  ./install.sh                    # 用户级安装
  ./install.sh --system           # 系统级安装 (需要 sudo)
  ./install.sh --prefix /opt      # 自定义路径
EOF
}

install_binary() {
    log_info "安装 JXTools 二进制文件..."
    log_info "安装路径: $INSTALL_DIR"
    
    mkdir -p "$INSTALL_DIR"
    
    if [ ! -f "./$BINARY_NAME" ]; then
        log_error "找不到二进制文件: $BINARY_NAME"
        return 1
    fi
    
    # 检查是否为二进制文件
    if file "./$BINARY_NAME" | grep -q "executable"; then
        log_info "确认为二进制可执行文件"
    else
        log_warn "文件类型检查: $(file "./$BINARY_NAME")"
    fi
    
    # 安装
    cp "./$BINARY_NAME" "$INSTALL_DIR/"
    chmod +x "$INSTALL_DIR/$BINARY_NAME"
    
    # 验证
    if "$INSTALL_DIR/$BINARY_NAME" --version >/dev/null 2>&1; then
        log_info "✅ 二进制文件验证成功"
    else
        log_warn "二进制文件验证失败，但已安装"
    fi
    
    # 检查 PATH
    if ! echo "$PATH" | grep -q "$INSTALL_DIR"; then
        log_warn "⚠️  $INSTALL_DIR 不在 PATH 中"
        log_info "请添加到 PATH: export PATH=\"\$PATH:$INSTALL_DIR\""
    fi
    
    log_info "🎉 二进制安装完成！"
    log_info "优势: 无需 bash 环境，独立运行"
    log_info "使用: $BINARY_NAME --help"
}

main() {
    local system_install=false
    
    while [ $# -gt 0 ]; do
        case "$1" in
            --prefix)
                INSTALL_PREFIX="$2"
                INSTALL_DIR="$INSTALL_PREFIX/bin"
                shift
                ;;
            --system)
                system_install=true
                INSTALL_PREFIX="/usr/local"
                INSTALL_DIR="$INSTALL_PREFIX/bin"
                ;;
            --uninstall)
                if [ -f "$INSTALL_DIR/$BINARY_NAME" ]; then
                    rm -f "$INSTALL_DIR/$BINARY_NAME"
                    log_info "已卸载: $INSTALL_DIR/$BINARY_NAME"
                else
                    log_info "未找到安装的文件"
                fi
                return 0
                ;;
            -h|--help)
                show_help
                return 0
                ;;
            *)
                log_error "未知选项: $1"
                return 1
                ;;
        esac
        shift
    done
    
    if [ "$system_install" = true ] && [ "$EUID" -ne 0 ]; then
        log_error "系统级安装需要 sudo 权限"
        return 1
    fi
    
    install_binary
}

main "$@"
