# LLDB 源码映射工具 (map_source.sh)

## 项目简介

本工具可以在使用二进制构建工程的同时，非常快速地将一个组件调出源码进行调试。

打个比方，我现在在我京工程运行，想看 `JDLTCommonUtilsModule` 这个二进制组件的某一个方法的实现，使用该工具即可实现，具体看下面效果:
![二进制工程调试，一键切换断点到源码位置](./Asserts/binary_to_source.gif)

`map_source.sh` 是一个专门为 iOS/macOS 开发者设计的 LLDB 调试辅助工具。它能够自动分析 `CocoaPods/MTools` 依赖库的二进制文件，提取编译时的源码路径，并生成 LLDB 源码映射配置，解决调试第三方库时无法正确显示源代码的问题。

### 解决的问题

在 iOS 开发中，当我们调试使用 CocoaPods 集成的第三方库时，经常会遇到以下问题：
- 断点进入第三方库代码时，显示汇编代码而非源代码
- 调用栈中的第三方库函数无法查看具体实现
- 调试时无法跟踪第三方库内部的执行流程

这是因为第三方库的二进制文件中记录的源码路径与本地源码路径不匹配导致的。

## 快速开始

### 基本用法

```bash
# 第一步：将该脚本拷贝到项目的根目录，即和Example同一级目录

# 第二步：执行脚本
# 最简单的使用方式：提供需要源码映射的模块名称和本地对应的源码的地址
./map_source.sh -m JDLTCommonUtilsModule -s /Users/denglibing3/HDProject/JDSpace/JDLTCode/JDLTCommonUtilsModule/JDLTCommonUtilsModule/Classes/ -p /Users/denglibing3/HDProject/JDSpace/JDLTCode/JDLTMyJdModule/Example/Pods/

# 第三步：启动 Xcode，在需要的地方添加断点，运行即可进入源码位置


# 🆕 新方式：自动应用到运行中的LLDB（推荐）
# 1. 在Xcode中开始调试并设置断点
# 2. 运行以下命令，自动应用配置（无需手动操作）
./map_source.sh -m JDLTCommonUtilsModule -s /Users/denglibing3/HDProject/JDSpace/JDLTCode/JDLTCommonUtilsModule/JDLTCommonUtilsModule/Classes/ -p /Users/denglibing3/HDProject/JDSpace/JDLTCode/JDLTMyJdModule/Example/Pods/ --attach

# 查看帮助信息
./map_source.sh --help
```

### 视频教程

二进制工程调试，一键切换断点到源码位置

![二进制工程调试，一键切换断点到源码位置](./Asserts/binary_to_source.gif)


二进制工程调试，添加源码引用到工程，在源码目录添加断点（更加高效和可维护性）

![二进制工程调试，添加源码到工程，在源码目录添加断点](/Asserts/binary_to_path.gif)

```bash
(lldb) breakpoint set -n "-[JDLTLaunchOptimize launchOptimizeMainSwitch]"
```

### 参数说明

| 参数 | 完整形式 | 必需 | 说明 | 示例 |
|------|----------|------|------|------|
| `-m` | `--module` | ✅ | 要处理的模块名称 | `-m AFNetworking` |
| `-s` | `--source` | ✅ | 本地源码路径 | `-s /path/to/source` |
| `-g` | `--global` | ❌ | 写入全局配置文件（默认选项） (~/.lldbinit) | `-g` |
| `-l` | `--local` | ❌ | 写入本地配置文件 (./.lldbinit) | `-l` |
| `-p` | `--pods-dir` | ❌ | 指定 Pods 目录路径（默认当前目录的 Example/Pods） | `-p Example/Pods` |
| `-d` | `--depth` | ❌ | 搜索深度（默认为10） | `-d 10` |
| `--attach` | `--attach` | ❌ | **🆕 自动将配置应用到运行中的Xcode LLDB会话，无需使用Xcode重新运行** | `--attach` |
| `-v` | `--verbose` | ❌ | 显示详细输出 | `-v` |
| `-q` | `--quiet` | ❌ | 静默模式 | `-q` |
| `-D` | `--debug` | ❌ | 显示调试信息 | `-D` |
| `-c` | `--config` | ❌ | 指定配置文件路径 | `-c /path/to/config` |

## 使用场景详解

### 场景一：🆕 自动应用到运行中的LLDB（推荐）

**最新功能！** 无需手动操作，自动将配置应用到当前运行的Xcode LLDB会话中。

```bash
# 1. 在Xcode中开始调试会话（设置断点并运行项目）
# 2. 运行脚本，自动应用配置
./map_source.sh -m AFNetworking -s ~/Source/AFNetworking/ -p /currentProject/Example/Pods/ --attach
```

**优点：**
- ✅ **零手动操作** - 无需复制粘贴命令
- ✅ **即时生效** - 配置立即应用到当前调试会话
- ✅ **智能检测** - 自动检测运行中的LLDB进程
- ✅ **多重保障** - 多种自动化方案，确保成功率

**工作原理：**
1. 检测运行中的LLDB进程
2. 通过AppleScript自动操作Xcode UI
3. 如果自动化失败，回退到剪贴板方案
4. 提供详细的操作指引

### 场景二：全局配置

适用于需要在多个项目中都使用相同第三方库的情况。

```bash
./map_source.sh -m AFNetworking -s ~/Pods/AFNetworking/AFNetworking/ --global
```

**优点：**
- 配置一次，所有项目都能使用
- LLDB 启动时自动加载配置
- 无需手动执行额外命令

### 场景三：项目本地配置

适用于项目特定的依赖库配置。

```bash
./map_source.sh -m ProjectSpecificModule -s ./LocalSource/ProjectSpecificModule/ --local
```

**注意：** 本地配置需要在 Xcode 中额外设置才能生效，请参考[相关文档](https://stackoverflow.com/questions/29791673/project-specific-lldbinit-in-current-working-directory-not-read-by-xcode)。

### 场景四：自定义 Pods 目录

```bash
./map_source.sh -m MyModule -s ~/Source/MyModule/ -p CustomPods/
```

### 场景五：批量处理多个模块

```bash
#!/bin/bash
modules=("AFNetworking" "SDWebImage" "Masonry")
for module in "${modules[@]}"; do
    ./map_source.sh -m "$module" -s "~/Source/$module/" -v
done
```

## 配置文件

### 创建配置文件

您可以创建 `~/.map_source.conf` 文件来设置默认配置：

```bash
# 默认 Pods 目录
PODS_DIR="Example/Pods"

# 默认配置类型 (global 或 local)
CONFIG_TYPE="global"

# 二进制文件扩展名过滤
BINARY_EXTENSIONS="h|m|swift|plist|xcconfig"

# 搜索深度
SEARCH_DEPTH=10

# 日志级别 (0=静默, 1=普通, 2=详细, 3=调试)
LOG_LEVEL=1
```

### 使用自定义配置文件

```bash
./map_source.sh -c /path/to/custom.conf -m MyModule -s ~/Source/MyModule/
```

## 实现原理详解

### 整体工作流程

```
[用户输入] → [参数解析] → [查找二进制文件] → [提取源码路径] → [生成LLDB配置] → [输出结果]
```

### 核心技术原理

#### 1. 二进制文件发现

工具使用 `find` 命令在指定的 Pods 目录中搜索 Mach-O 格式的二进制文件：

```bash
find "$module_path" -maxdepth "$SEARCH_DEPTH" -type f -print0
```

通过 `file` 命令识别 Mach-O 格式：
```bash
file_type=$(file -b "$file")
if [[ "$file_type" == *"Mach-O"* ]]; then
    # 这是一个二进制文件
fi
```

#### 2. 多架构处理

现代 iOS 应用通常包含多个架构（arm64、x86_64），工具会分别处理每个架构：

```bash
# 获取所有架构
archs=$(lipo -info "$binary" | grep -o "arm64\|x86_64")

# 提取特定架构
lipo "${input_file}" -thin "${arch}" -output "${output_file}"
```

#### 3. DWARF 调试信息解析

这是工具的核心技术，使用 `dwarfdump` 命令解析二进制文件中的 DWARF 调试信息：

```bash
# 提取调试信息
dwarf_output=$(dwarfdump "$binary" 2>/dev/null | grep -E "$module_name\.(m|mm|swift)")

# 解析 DW_AT_name 属性获取源码路径
source_path=$(echo "$dwarf_output" | grep "DW_AT_name" | sed -n 's/.*DW_AT_name[[:space:]]*("\(.*\)").*/\1/p')
```

#### 4. LLDB 映射配置生成 （核心代码）

工具生成标准的 LLDB `target.source-map` 配置：

```bash
settings append target.source-map /original/build/path /local/source/path
```

**🆕 新特性：自动清除冲突配置**

脚本现在会自动在.lldbinit文件开头添加清除命令，避免路径映射冲突：

```bash
# .lldbinit 文件结构
settings clear target.source-map
settings append target.source-map /var/tmp/iBiu_release/JDLTUIKitModule/App-Lint/JDLTUIKitModule/Classes/ /Users/user/Source/JDLTUIKitModule/Classes/
settings append target.source-map /var/tmp/iBiu_release/back/JDLTUIKitModule/App-Lint/JDLTUIKitModule/Classes/ /Users/user/Source/JDLTUIKitModule/Classes/
```

常用的 LLDB 映射配置：

```bash
# 1、🆕 自动清理映射关系（脚本自动添加）
settings clear target.source-map

# 2、追加映射关系：
# 向 target.source-map 设置中追加一组路径映射。用于当你的本地源码路径和编译时源码路径不一致时，告诉 LLDB 如何找到正确的源码。
settings append target.source-map <编译时路径> <本地源码路径>

# 3、覆盖映射关系：
# 覆盖当前所有 source-map 设置，一次性指定所有映射。
settings set target.source-map <编译时路径1> <本地源码路径1> [<编译时路径2> <本地源码路径2> ...]

# 4、显示当前的 source-map 设置
settings show target.source-map
```

### 技术细节深入

#### DWARF 调试信息格式

DWARF (Debugging With Attributed Record Formats) 是一种调试信息格式，包含：

- **DW_AT_name**: 源文件名和路径
- **DW_AT_comp_dir**: 编译目录
- **DW_TAG_compile_unit**: 编译单元信息

#### 路径映射原理

LLDB 的源码映射机制：
1. 调试器读取二进制文件中的原始源码路径
2. 通过 `target.source-map` 将原始路径映射到本地路径
3. 调试时自动使用映射后的路径查找源文件

#### 架构兼容性处理

```bash
# 处理通用二进制文件（Universal Binary）
for arch in $archs; do
    # 提取单一架构
    extract_arch "$binary" "$arch" "$arch_binary"
    
    # 分别处理每个架构的调试信息
    get_source_path "$arch_binary" "$module_name"
done
```

## 高级用法

### 1. 批量配置脚本

创建一个批量配置脚本 `batch_config.sh`：

```bash
#!/bin/bash

# 配置多个常用库
declare -A modules=(
    ["AFNetworking"]="~/Source/AFNetworking/"
    ["SDWebImage"]="~/Source/SDWebImage/"
    ["Masonry"]="~/Source/Masonry/"
)

for module in "${!modules[@]}"; do
    echo "配置模块: $module"
    ./map_source.sh -m "$module" -s "${modules[$module]}" -v
done
```

### 2. 集成到构建流程

在 Xcode Build Phases 中添加：

```bash
# 在 Build Phases 中添加 Run Script
if [ -f "${SRCROOT}/map_source.sh" ]; then
    "${SRCROOT}/map_source.sh" -m YourModule -s "${SRCROOT}/YourModule/" -q
fi
```


## 故障排除

### 常见问题
**选择的二进制版本，一定要和选择的源码版本一致！**

**选择的二进制版本，一定要和选择的源码版本一致！**

**选择的二进制版本，一定要和选择的源码版本一致！**


#### 1. 无法找到二进制文件

**原因：** Pods 目录路径不正确或模块名错误

**Xcode提示日志** 

```bash
Can't show file for stack frame : <DBGLLDBStackFrame: 0x53baa30a0> - stackNumber:0 - name:+[JDLTAppConfigs appName]. The file path does not exist on the file system: /var/tmp/iBiu_release/back/JDLTCommonUtilsModule/App-Lint/JDLTCommonUtilsModule/Classes/Configs/JDLTAppConfigs.m
```

**解决方案：**

```bash
# 检查 Pods 目录结构
ls -la Example/Pods/YourModule/

# 使用 -d 参数增加搜索深度
./map_source.sh -m YourModule -s /path/to/source -d 15
```

#### 2. 无法提取源码路径

**原因：** 二进制文件没有包含调试信息

**解决方案：**

```bash
# 检查二进制文件是否包含调试信息
dwarfdump Example/Pods/YourModule/YourModule | grep DW_AT_name

# 确保 CocoaPods 配置包含调试符号
# 在 Podfile 中添加：
post_install do |installer|
  installer.pods_project.targets.each do |target|
    target.build_configurations.each do |config|
      config.build_settings['DEBUG_INFORMATION_FORMAT'] = 'dwarf-with-dsym'
    end
  end
end
```

#### 3. LLDB 配置不生效

**检查步骤：**

```bash
# 1. 验证配置文件内容
cat ~/.lldbinit | grep "target.source-map"

# 2. 在 LLDB 中手动测试
(lldb) settings show target.source-map

# 3. 重新加载配置文件
(lldb) command source ~/.lldbinit
```

#### 4. 🆕 --attach 模式故障排除

**问题：未找到运行中的LLDB进程**

```
警告: 未找到运行中的LLDB进程
请确保在Xcode中已开始调试会话
```

**解决方案：**

1. **确保Xcode调试会话已启动**
   ```bash
   # 1. 在Xcode中设置断点
   # 2. 运行项目并触发断点
   # 3. 确保LLDB控制台处于活动状态
   ```

2. **手动检查LLDB进程**
   ```bash
   # 检查LLDB相关进程
   ps aux | grep lldb
   ps aux | grep debugserver
   ```

3. **使用调试模式获取详细信息**
   ```bash
   ./map_source.sh -m YourModule -s /path/to/source --attach --debug
   ```

**问题：AppleScript自动化失败**

**解决方案：**

1. **检查系统权限**
   - 系统偏好设置 → 安全性与隐私 → 隐私 → 辅助功能
   - 确保终端应用已获得辅助功能权限

2. **使用备用方案**
   - 脚本会自动回退到剪贴板方案
   - 手动在LLDB控制台中粘贴命令

3. **手动应用配置**
   ```bash
   # 在LLDB控制台中执行
   (lldb) command source ~/.lldbinit
   ```

### 调试模式

使用调试模式获取详细信息：

```bash
./map_source.sh -m YourModule -s /path/to/source --debug
```

调试输出包括：

- 文件搜索过程
- 架构提取详情
- DWARF 信息解析
- 配置写入过程

## 性能优化

### 1. 缓存机制

工具会自动检查配置是否已存在，避免重复处理：

```bash
if ! grep -q "settings append target.source-map $binary_source_path $source_path" "$lldbinit"; then
    # 只在配置不存在时才添加
fi
```

### 2. 并行处理

对于大型项目，可以并行处理多个模块：

```bash
#!/bin/bash
modules=("Module1" "Module2" "Module3")

for module in "${modules[@]}"; do
    (./map_source.sh -m "$module" -s "~/Source/$module/" -q) &
done

wait  # 等待所有后台任务完成
```

## 最佳实践

### 1. 项目集成建议

- 将 `map_source.sh` 放在项目根目录
- 创建项目专用的配置文件
- 在 README 中记录使用的第三方库配置命令

### 2. 团队协作

- 提交 `.map_source.conf` 配置文件到版本控制
- 在项目文档中说明调试环境设置步骤
- 考虑将配置命令集成到项目的 Makefile 或脚本中

### 3. 版本管理

- 为不同版本的第三方库维护不同的配置
- 使用版本标签管理源码路径映射
- 定期清理过期的 LLDB 配置

## 扩展开发

### 添加新功能

工具采用模块化设计，易于扩展：

```bash
# 添加新的二进制文件类型支持
process_new_binary_type() {
    local binary="$1"
    # 自定义处理逻辑
}

# 添加新的输出格式
generate_custom_output() {
    local config="$1"
    # 生成自定义格式的配置
}
```

### 插件机制

可以通过配置文件定义插件：

```bash
# 在配置文件中定义插件路径
PLUGIN_DIR="~/.map_source_plugins"

# 加载插件
for plugin in "$PLUGIN_DIR"/*.sh; do
    source "$plugin"
done
```

## 技术支持

如果您遇到问题或有改进建议，请：

1. 首先查看本文档的故障排除部分
2. 使用 `--debug` 模式收集详细日志
3. 检查您的环境是否满足依赖要求：
   - macOS 系统
   - Xcode 命令行工具
   - 包含调试信息的 CocoaPods 依赖


## 参考资料

[美团 iOS 工程 zsource 命令背后的那些事儿](https://tech.meituan.com/2019/08/08/the-things-behind-the-ios-project-zsource-command.html)

[iOS调试二进制源码](https://juejin.cn/post/7373946076762980389)


**本工具由京东特价版开发团队开发维护。**

---

*最后更新: 2025-07-23*

## 版本更新记录

### v1.1.0 (2025-07-23)
- 🆕 **新增 `--attach` 功能**：自动将配置应用到运行中的Xcode LLDB会话
- 🔧 **改进配置管理**：自动在.lldbinit文件开头添加`settings clear target.source-map`，避免路径映射冲突
- 🚀 **多重自动化方案**：AppleScript自动化 + UNIX socket通信 + 剪贴板备用方案
- 🐛 **修复配置读取问题**：优化grep模式，确保读取所有相关配置
- 📚 **完善文档**：更新README，添加新功能使用说明和故障排除指引

### v1.0.0 (2025-07-22)
- 🎉 **首个稳定版本发布**
- ✅ **核心功能**：自动分析二进制文件，生成LLDB源码映射配置
- ✅ **多架构支持**：支持arm64、x86_64架构
- ✅ **配置文件支持**：支持全局和本地配置文件
- ✅ **详细日志**：支持verbose和debug模式